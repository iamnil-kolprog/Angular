import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private rout:Router) { }
  username;
  pass;

  login(){
    if(this.username=='Nilanjan' && this.pass=='12345'){
      localStorage.setItem('user',this.username)
      localStorage.setItem('role','admin')
      this.rout.navigate(['home'])
    }else{
      localStorage.setItem('user',this.username)
      localStorage.setItem('role','customer')
      this.rout.navigate(['home'])
    }
  }

  ngOnInit() {
  }

}
