import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  constructor(private ps:ProductService,private rout:Router) { }

  product={
    name:'',
    desp:'',
    price:''
  }

  addProd(){
    this.ps.add(this.product).subscribe(()=>{
      alert("Data Added...")
      this.rout.navigate(['home'])
    })
  }

  ngOnInit() {
  }

}
