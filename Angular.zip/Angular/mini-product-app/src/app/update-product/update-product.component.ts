import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {

  product;

  constructor(private ps:ProductService,private rout :Router) {
    this.product=history.state.product;
   }

  updateProduct(){
    this.ps.updateProduct(this.product).subscribe(()=>{alert("Data Edited...")
    this.rout.navigate(['home'])
    })
  }

  


  ngOnInit() {
  }

}
