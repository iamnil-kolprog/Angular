import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  products;
  i;

  constructor(private ps:ProductService,private r:Router) {
    if(localStorage.getItem('user')==null){
      r.navigate([''])
    }
    ps.getAll().subscribe((res)=>this.products=res)
   }

   removeProduct(pid){
     this.ps.remove(pid).subscribe(()=>{
       alert("Deleted.....")
       history.go()
     })
   }

   logout(){
     localStorage.clear();
     this.r.navigate([''])
   }

  ngOnInit() {
  }

}
