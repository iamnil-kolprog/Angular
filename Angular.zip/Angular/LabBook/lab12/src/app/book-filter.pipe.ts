import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'bookFilter'
})
export class BookFilterPipe implements PipeTransform {

  // transform(books,i,t,a,y) {
  //   let dbook=[];
    
  //   for(let j=0;j<books.length;j++){
  //     if(books[j].id==i || books[j].title.includes(t) || books[j].author.includes(a) || books[j].year==y){
  //       dbook.push(books[j]);
  //     }
  //   }
  //   return dbook;
  // }
  
  transform(values,i,t,a,y){
    if(i!=''){
      return values.filter((books)=>books.id==i)
    }else if(t!=''){
      return values.filter((books)=>books.title.includes(t))
    }else if(a!=''){
      return values.filter((books)=>books.author.includes(a))
    }else if(y!=''){
      return values.filter((books)=>books.year==y)
    }else{
      return values;
    }

  }
}
