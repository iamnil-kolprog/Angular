import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LabAddEmpComponent } from './lab-add-emp/lab-add-emp.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { LabAddArrayEmpComponent } from './lab-add-array-emp/lab-add-array-emp.component';
import { Lab21EmpComponent } from './lab21-emp/lab21-emp.component';
import { Lab42Component } from './lab42/lab42.component';
import { BookFilterPipe } from './book-filter.pipe';
import { Lab3Component } from './lab3/lab3.component';
import { Lab5Component } from './lab5/lab5.component';

@NgModule({
  declarations: [
    AppComponent,
    LabAddEmpComponent,
    LabAddArrayEmpComponent,
    Lab21EmpComponent,
    Lab42Component,
    BookFilterPipe,
    Lab3Component,
    Lab5Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
