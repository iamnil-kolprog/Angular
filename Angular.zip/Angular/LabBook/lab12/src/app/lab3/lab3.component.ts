import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-lab3',
  templateUrl: './lab3.component.html',
  styleUrls: ['./lab3.component.css']
})
export class Lab3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  myForm=new FormGroup({
      Id:new FormControl('',[Validators.required]),
      Name:new FormControl('',[Validators.required]),
      Cost:new FormControl('',[Validators.required]),
      Online:new FormControl('',[Validators.required]),
      Cat:new FormControl('',[Validators.required]),
      Store:new FormControl('',[Validators.requiredTrue])
  });

  e_msg={
    'Id':[
      {type:'required',msg:'ID should not be empty'}
    ],
    'Name':[
    {type:'required',msg:'Name should be given'}
    ],
    'Cost':[
      {type:'required',msg:'cost should not be empty'}
    ],
    'Online':[
      {type:'required',msg:'You must select one option'}
    ],
    'Cat':[
      {type:'required',msg:'Category should be something'}
    ],
    'Store':[
      {type:'required',msg:"Category option must be checked"}
    ]
  }

  cata=['Grocery','Mobile','Electronics','Clothes'];

  pid;
  pname;
  pcost;
  pon;
  pcat;
  //pst;
  pst1;
  pst2;
  pst3;
  pst4;



  onFormSubmit(){

    console.log(this.pid+" "+this.pname+" "+this.pcost+" "+this.pon+" "+(this.pst1 || this.pst2 || this.pst3 || this.pst4));
  }


}
