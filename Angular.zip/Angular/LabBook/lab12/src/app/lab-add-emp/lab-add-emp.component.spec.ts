import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LabAddEmpComponent } from './lab-add-emp.component';

describe('LabAddEmpComponent', () => {
  let component: LabAddEmpComponent;
  let fixture: ComponentFixture<LabAddEmpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LabAddEmpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LabAddEmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
