import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab-add-emp',
  templateUrl: './lab-add-emp.component.html',
  styleUrls: ['./lab-add-emp.component.css']
})
export class LabAddEmpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  id;
  name;
  sal;
  dept;

  add(){
    alert(this.id+" "+this.name+" "+" "+this.sal+" "+this.dept);
  }


}
