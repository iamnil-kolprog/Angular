import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Lab21EmpComponent } from './lab21-emp.component';

describe('Lab21EmpComponent', () => {
  let component: Lab21EmpComponent;
  let fixture: ComponentFixture<Lab21EmpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Lab21EmpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Lab21EmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
