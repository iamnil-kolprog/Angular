import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab21-emp',
  templateUrl: './lab21-emp.component.html',
  styleUrls: ['./lab21-emp.component.css']
})
export class Lab21EmpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  id;
  name;
  sal;
  dept;
  arr=[];
  add(){
    this.arr.push({Id:this.id,Name:this.name,Salary:this.sal,Dept:this.dept});
}
remove(ind){
  this.arr.splice(ind,1);
}
uid;
uname;
usal;
udept;
update(n){
  this.uid=this.arr[n].Id;
  this.uname=this.arr[n].Name;
  this.usal=this.arr[n].Salary;
  this.udept=this.arr[n].Dept;
}

}
