import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab-add-array-emp',
  templateUrl: './lab-add-array-emp.component.html',
  styleUrls: ['./lab-add-array-emp.component.css']
})
export class LabAddArrayEmpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  d=new Date();

  id;
  name;
  sal;
  dept;
  aId=[];
  aName=[];
  aSal=[];
  aDept=[];

  add(){
    this.aId.push(this.id);
    this.aName.push(this.name);
    this.aSal.push(this.sal);
    this.aDept.push(this.dept);
  }
  index;
  remove(index){
    this.aId.splice(index,1);
    this.aName.splice(index,1);
    this.aSal.splice(index,1);
    this.aDept.splice(index,1);
    
  }
  uid;
  uname;
  usal;
  udept;
  update(nil){
    this.uid=this.aId[nil];
    this.uname=this.aName[nil];
    this.usal=this.aSal[nil];
    this.udept=this.aDept[nil];

  }

}
