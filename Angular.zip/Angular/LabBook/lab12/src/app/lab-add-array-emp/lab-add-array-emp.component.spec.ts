import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LabAddArrayEmpComponent } from './lab-add-array-emp.component';

describe('LabAddArrayEmpComponent', () => {
  let component: LabAddArrayEmpComponent;
  let fixture: ComponentFixture<LabAddArrayEmpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LabAddArrayEmpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LabAddArrayEmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
