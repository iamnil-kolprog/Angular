import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab5',
  templateUrl: './lab5.component.html',
  styleUrls: ['./lab5.component.css']
})
export class Lab5Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
