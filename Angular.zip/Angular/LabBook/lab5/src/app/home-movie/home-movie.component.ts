import { Component, OnInit } from '@angular/core';
import { MoviesService } from '../movies.service';

@Component({
  selector: 'app-home-movie',
  templateUrl: './home-movie.component.html',
  styleUrls: ['./home-movie.component.css']
})
export class HomeMovieComponent implements OnInit {

  movies;

  constructor(private ms:MoviesService) {
      ms.getAll().subscribe((res)=>this.movies=res)
   }


  ngOnInit() {
  }

}
