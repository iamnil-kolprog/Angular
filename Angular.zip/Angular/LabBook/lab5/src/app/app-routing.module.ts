import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeMovieComponent } from './home-movie/home-movie.component';
import { AddMovieComponent } from './add-movie/add-movie.component';
import { SearchComponent } from './search/search.component';


const routes: Routes = [
  {path:'',component:HomeMovieComponent},
  {path:'add',component:AddMovieComponent},
  {path:'search',component:SearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
