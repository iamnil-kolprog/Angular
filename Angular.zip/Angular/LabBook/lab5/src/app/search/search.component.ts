import { Component, OnInit } from '@angular/core';
import { MoviesService } from '../movies.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor(private ms:MoviesService) { }

  ngOnInit() {
  }
  movie;
  searchMovie(){
    this.ms.getAll().subscribe((r)=>this.movie=r)
  }


}
