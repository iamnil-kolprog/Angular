import { Component, OnInit } from '@angular/core';
import { MoviesService } from '../movies.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {

  constructor(private ps:MoviesService,private rout:Router) { }

  movie={
    'name':'',
    'rating':'',
    'genre':''
  }
  addMovie(){
    this.ps.add(this.movie).subscribe(()=>{
      alert("Movie Added...")
      this.rout.navigate([''])
    })
  }



  ngOnInit() {
  }

}
