import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MoviesService {

  constructor(private http:HttpClient) { }

  add(mov){
    let opt = new HttpHeaders({'Content-Type':'application/json'})
    return this.http.post('http://localhost:3000/movies',mov,{headers:opt})
  }

  getAll(){
    return this.http.get('http://localhost:3000/movies')
  }

  search(s){
    return this.http.get('http://localhost:3000/movies/'+s)
  }

}
