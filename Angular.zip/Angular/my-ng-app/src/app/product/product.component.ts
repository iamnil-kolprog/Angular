import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  username:string="Nilanjan Saha"

  age:number=22

  langs =['java','pega','angular','react','vue']

  products = [
    {id:1, name: 'apple',price : 49},
    {id:2, name: 'pen',price : 10},
    {id:3, name: 'pencil',price : 25}
  ]

  display(){
    alert("Hi ,this  is display fun")
  }

}
