import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  product;

  constructor(private ps:ProductService) {                     //creating instance or object of product service
      ps.getAll().subscribe((res)=>this.product=res)      //calling getAll() function of service class and store values in product property
  }

  remove(pid){
    this.ps.remove(pid).subscribe(()=>{
      alert("deleted...")
      history.go();
    })
  }

  /*
  remove is a function ,takes a parameter pid which holds the value of 'id' of select products.
  and it also receive the values .
  print a alert box
  and also it move to same page, for this I use history.go()
    */

  ngOnInit() {
  }

}
