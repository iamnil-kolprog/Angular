import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor(private ps:ProductService) { }          //creating a reference of Product Service

  searchProduct(){
    this.s=this.ser;                                      //
    this.ps.getAll().subscribe((res)=>this.prod=res)
  }

  /*
  it takes all the values from server and store in prod
  */ 



  prod;                                         
  ser;                                  //properties of this class.
  s;                                    //storing the search value in ser from search.html by [(ngModel)]
                                      
  ngOnInit() {
  }

}
