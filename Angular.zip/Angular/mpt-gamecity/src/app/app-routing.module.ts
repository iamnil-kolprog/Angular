import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PlayAppComponent } from './play-app/play-app.component';
import { GameAppComponent } from './game-app/game-app.component';


const routes: Routes = [
  {path:'play/:amt',component:PlayAppComponent},
  {path:'',component:GameAppComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
