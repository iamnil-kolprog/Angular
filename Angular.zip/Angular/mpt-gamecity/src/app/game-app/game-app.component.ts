import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-game-app',
  templateUrl: './game-app.component.html',
  styleUrls: ['./game-app.component.css']
})
export class GameAppComponent implements OnInit {

  constructor(private rout:Router) { }
  name;
  add;
  amt;
  N;

  buy(){
        this.N=this.amt-100;
        this.rout.navigateByUrl('/play/'+this.N)
      }

  ngOnInit() {
  }

}
