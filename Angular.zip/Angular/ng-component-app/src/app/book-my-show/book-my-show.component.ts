import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-my-show',
  templateUrl: './book-my-show.component.html',
  styleUrls: ['./book-my-show.component.css']
})
export class BookMyShowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  tickets;
  amount;
  price:number=150
  cal(){
    if(this.tickets>10){
      alert("ticket no. should be in 1 to 10");
    }else{
    this.amount=this.tickets*this.price
    }
  }

}
