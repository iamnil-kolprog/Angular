import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  Products=[
    {id:5, name:'apple', price:50},
    {id:10, name:'pen', price:25},
    {id:15, name:'pencil', price:15}
  ]

  product;
  
  selectedProduct(product){
    this.product=product;
  }
}
