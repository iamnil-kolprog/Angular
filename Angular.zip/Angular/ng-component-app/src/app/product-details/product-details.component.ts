import { Component, OnInit } from '@angular/core';
import { CommentStmt, templateVisitAll } from '@angular/compiler';
import { totalmem } from 'os';
import { ChildrenOutletContexts } from '@angular/router';
import { NONE_TYPE } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  cat=['Electronics','Grocery'];
  elec=[
    {name:'TV',price:20000},
    {name:'Laptop',price:30000},
    {name:'Phone',price:10000}
  ]
  groc=[
    {name:'soap',price:40},
    {name:'powder',price:90}
  ]
  ch;
  ch1;
  ch2;
  i;
  p;
  total;
  cost(quantity){
    if(this.ch=="Electronics"){
    if(this.ch1=="TV"){
        this.p=20000;
    }else if(this.ch1=="Laptop")
    {
      this.p=30000;
    }
    else{
      this.p=10000;
    }
  }else{
    if(this.ch2=="soap"){
      this.p=40;
  }else
  {
    this.p=90;
  }
    
  }
  this.total=this.p*quantity;

}

reset(){
  this.total=0;
}
}
