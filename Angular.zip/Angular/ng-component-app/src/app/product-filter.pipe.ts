import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'productFilter'
})
export class ProductFilterPipe implements PipeTransform {

  transform(product,s){
    let prod=[]
    for(let i=0;i<product.length;i++){
        if(product[i].name==s){
            prod.push(product[i]);
        }
    }
    return prod;
  }

}
