import { Component, OnInit } from '@angular/core';
import { element } from 'protractor';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  // elemnet;
  
  arr=[];
  
  add(e){
    this.arr.push(e)
  }
  remove(ind){
    this.arr.splice(ind,1)
  }

}
