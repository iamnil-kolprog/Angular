import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-state-city-desc',
  templateUrl: './state-city-desc.component.html',
  styleUrls: ['./state-city-desc.component.css']
})
export class StateCityDescComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  states=['West-Bengal','Tamilnadu','MadhyaPradesh'];
  cityW=['Kolkata','Howrah','Malda'];
  cityT=['chennai','coimbatore','chengalpattu'];
  cityM=['bhopal','indore','gwalior']

}
