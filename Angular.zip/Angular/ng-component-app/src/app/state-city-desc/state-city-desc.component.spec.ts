import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StateCityDescComponent } from './state-city-desc.component';

describe('StateCityDescComponent', () => {
  let component: StateCityDescComponent;
  let fixture: ComponentFixture<StateCityDescComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StateCityDescComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StateCityDescComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
