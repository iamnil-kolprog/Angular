import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(data,x){
    //return data.sort().reverse();
    let fa=[];
    // for(let i=0;i<data.length;i++){
    //   if(data[i]==x){
    //     fa.push(data[i]);
    //   }
    // }
    for(let i=0;i<data.length;i++){
      if(data[i].includes(x)){
        fa.push(data[i]);
      }
    }
    return fa;
  }

}
