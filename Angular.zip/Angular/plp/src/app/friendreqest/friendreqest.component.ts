import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-friendreqest',
  templateUrl: './friendreqest.component.html',
  styleUrls: ['./friendreqest.component.css']
})
export class FriendreqestComponent implements OnInit {

  data;
  username;
  constructor(private s: ServiceService) {
    this.username=history.state.username
    this.s.getAll(this.username).subscribe((res)=>this.data=res)
      }
 
  ngOnInit() {
  }
  
  clicked;

  friendList={
    fromName:'',
    toName:'',
    friendStatus:0
  }
  addFriend(event :any,d){
      event.target.disabled=true;
      
      this.friendList.fromName=this.username;
      //alert(this.username)
      this.friendList.toName=d;
      this.friendList.friendStatus=1;
      this.s.addFriendRequest(this.friendList).subscribe(()=>{
      alert("frined request sent to "+d)
      })
  }


 

}
   