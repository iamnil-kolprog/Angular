import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FriendreqestComponent } from './friendreqest.component';

describe('FriendreqestComponent', () => {
  let component: FriendreqestComponent;
  let fixture: ComponentFixture<FriendreqestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FriendreqestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FriendreqestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
