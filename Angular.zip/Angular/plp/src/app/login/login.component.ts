import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private serv:ServiceService) { }
 customer={
    username:'',
    password:''
 }

// name;
// pass;
  ngOnInit() {
  }

  login(){
   
    this.serv.add(this.customer).subscribe(()=>{alert("credential added")})
  }

}
