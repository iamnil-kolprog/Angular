import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  constructor(private s : ServiceService,private rout : Router) {
    
   }

  newpass;
  confirmpass;

  user={
    username:'',
    password:''
  }

  changePassword() {
    if(this.newpass!=this.confirmpass){
      alert("password not matched")
    }else if(this.user.password==this.newpass){
      alert("New password is equal to old password. please put the new password")
    }
    else {
      this.s.change(this.user,this.newpass).subscribe(()=>{
        alert("PassWord Changed...")
        this.rout.navigate([''])
      })
    }
  }



  ngOnInit() {
  }

}
