import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { LoginComponent } from './login/login.component';


@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(private http : HttpClient) { }

  add(user){
    return this.http.post('http://localhost:8871/user',user);
  }
  change(user,newpass){
    
    
    let url='http://localhost:8871/user/'
    return this.http.put(url+user.username+'/'+newpass,user);
  }

  getAll(us){
    return this.http.get('http://localhost:8871/getAll/'+us);
  }

  addFriendRequest(friendList){
    return this.http.post('http://localhost:8871/addfriend',friendList);
  }

  getRequests(toName){
    return this.http.get('http://localhost:8871/addfriend/'+toName)
  }

  remove(fromName,toNam){
    return this.http.delete('http://localhost:8871/delete/'+fromName+"/"+toNam)
  }

  accept(fromName,friendList){
    return this.http.put('http://localhost:8871/accept/'+fromName,friendList)
  }

  friends(name){
    return this.http.get('http://localhost:8871/getFriends/'+name)
  }
}
