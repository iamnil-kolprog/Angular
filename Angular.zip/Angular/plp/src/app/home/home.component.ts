import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  username;

  constructor(private serv :ServiceService) {
      this.username=history.state.username
   }
   requests;

  friendRequest(){
    this.serv.getRequests(this.username).subscribe((res)=>this.requests=res)
  }
  friendList={
    fromName:'',
    toName:'',
    friendStatus:0
  }
  friend;
  friends(){
    this.serv.friends(this.username).subscribe((res)=>
    {
      this.friend=res;
    })
  }


  decline(r){

    this.serv.remove(r,this.username).subscribe(()=>{
      alert("request deleted..")
      history.go()
    })

  }

  accept(r){
    this.friendList.toName=this.username;
    this.friendList.fromName=r;
    this.friendList.friendStatus=2;
    this.serv.accept(r,this.friendList).subscribe(()=>{
      alert("friend request accepted")
       
      

    })
  }
  ngOnInit() {
  }

}
