import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-register-from',
  templateUrl: './register-from.component.html',
  styleUrls: ['./register-from.component.css']
})
export class RegisterFromComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  myForm=new FormGroup({
    username:new FormControl('',[Validators.required]),
    password:new FormControl('',[Validators.required]),
    email:new FormControl('',[Validators.required]),
    languages:new FormControl('',[Validators.required]),
    gender :new FormControl('',[Validators.required])
  })

  error_messages={
    'username':[
      {type :'required',messages :'field should not be empty'}
    ],
    'password':[
      {type :'required',messages :'field should not be empty'}
    ],
    'email':[
      {type:'required',messages:'feild should not be empty'}
    ],
    'languages' :[
      {type:'required',messages:'feild should not be empty'}
    ],
    'gender':[
      {type:'required',messages:'button should not be empty'}
    ]
  }
  languages=['java','javascript'];

}
