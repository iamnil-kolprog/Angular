import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-template-form',
  templateUrl: './template-form.component.html',
  styleUrls: ['./template-form.component.css']
})
export class TemplateFormComponent implements OnInit {

  username;password;
  skill;
  gender;
  lang1;
  lang2;
  lang3;
  skills=['java','angular','node','react']

  // userdetails(){
  //   if(this.username !=''){
  //     if(this.password!=''){
  //       if(this.skill!=''){
  //         if(this.gender!=''){
  //           alert('hello, good afternoon')
  //         }
  //       }
  //     }
  //   }
  // }

  constructor(private rout :Router) { }

  ngOnInit() {
  }

  userdetails(){
    this.rout.navigateByUrl('/success/'+this.username)
  }

}
